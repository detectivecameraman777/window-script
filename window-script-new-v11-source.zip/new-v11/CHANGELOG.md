# Changelog

## V11 — 2026-08-22
### Added
- Windows version information.
- Windows Recovery status menu.
- Better invalid-input handling.

### Changed
- Improved command structure.
- Added local environment isolation.
- Updated title and menu to V11.

## V10 — 2026-08-22
### Added
- Language selection menu.
- Installed-language display.
- UTF-8 console support.
- Multiple Windows locale options.

## V1–V9
Historical versions are not present in the current repository commit history. The repository currently shows the V10 file as its available commit snapshot.
