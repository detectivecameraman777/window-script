# Windows 11 Recovery Manager V11 — Updated Source

Updated source based on the V10 project.

## Changes in V11
- Improved input handling.
- Added Windows version information.
- Added Windows Recovery Environment status display using `reagentc /info`.
- Added clearer invalid-selection handling.
- Added `setlocal` / `endlocal`.
- Kept the existing language menu.
- Does not automatically install or remove language packs or recovery partitions.

## Files
- `windows-11.cmd`
- `README.md`
- `CHANGELOG.md`
