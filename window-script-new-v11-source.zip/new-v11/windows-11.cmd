﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Windows 11 Recovery Manager V11

:MENU
cls
echo ==========================================
echo Windows 11 Recovery Manager V11
echo ==========================================
echo.
echo 1. English (United States)
echo 2. German (Germany)
echo 3. German (India) - LOCALE
echo 4. French (France)
echo 5. Spanish (Spain)
echo 6. Italian (Italy)
echo 7. Portuguese (Portugal)
echo 8. Polish (Poland)
echo 9. Croatian (Croatia)
echo 10. Japanese (Japan)
echo 11. Korean (Korea)
echo 12. Chinese (Simplified)
echo 13. Chinese (Traditional)
echo 14. Show installed languages
echo 15. Show Windows version
echo 16. Show recovery status
echo 0. Exit
echo.
set "choice="
set /p "choice=Select option: "

if "%choice%"=="1" set "LANG=en-US"&goto APPLY
if "%choice%"=="2" set "LANG=de-DE"&goto APPLY
if "%choice%"=="3" set "LANG=de-IN"&goto APPLY
if "%choice%"=="4" set "LANG=fr-FR"&goto APPLY
if "%choice%"=="5" set "LANG=es-ES"&goto APPLY
if "%choice%"=="6" set "LANG=it-IT"&goto APPLY
if "%choice%"=="7" set "LANG=pt-PT"&goto APPLY
if "%choice%"=="8" set "LANG=pl-PL"&goto APPLY
if "%choice%"=="9" set "LANG=hr-HR"&goto APPLY
if "%choice%"=="10" set "LANG=ja-JP"&goto APPLY
if "%choice%"=="11" set "LANG=ko-KR"&goto APPLY
if "%choice%"=="12" set "LANG=zh-CN"&goto APPLY
if "%choice%"=="13" set "LANG=zh-TW"&goto APPLY
if "%choice%"=="14" goto LIST
if "%choice%"=="15" goto VERSION
if "%choice%"=="16" goto RECOVERY
if "%choice%"=="0" goto EXIT

echo.
echo Invalid selection.
timeout /t 2 /nobreak >nul
goto MENU

:APPLY
cls
echo ==========================================
echo Selected Windows locale
echo ==========================================
echo.
echo Locale: %LANG%
echo.
echo This project displays the selected locale.
echo It does not install language packs automatically.
echo.
pause
goto MENU

:LIST
cls
echo ==========================================
echo Installed Windows Languages
echo ==========================================
echo.
dism /online /get-intl
echo.
pause
goto MENU

:VERSION
cls
echo ==========================================
echo Windows Version
echo ==========================================
echo.
ver
echo.
systeminfo | findstr /B /C:"OS Name" /C:"OS Version"
echo.
pause
goto MENU

:RECOVERY
cls
echo ==========================================
echo Windows Recovery Status
echo ==========================================
echo.
reagentc /info
echo.
pause
goto MENU

:EXIT
endlocal
exit /b
