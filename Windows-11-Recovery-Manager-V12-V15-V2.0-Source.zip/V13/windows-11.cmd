﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Windows 11 Recovery Manager V13

:MENU
cls
echo ==========================================
echo Windows 11 Recovery Manager V13
echo ==========================================
echo.
echo 1. Show installed languages
echo 2. Show Windows version
echo 3. Show Recovery Environment status
echo 4. System diagnostics
echo 0. Exit
echo.
set "choice="
set /p "choice=Select option: "

if "%choice%"=="1" goto LANG
if "%choice%"=="2" goto VERSION
if "%choice%"=="3" goto RECOVERY
if "%choice%"=="4" goto DIAG
if "%choice%"=="0" goto EXIT

echo Invalid selection.
timeout /t 2 /nobreak >nul
goto MENU

:LANG
cls
echo === Installed Windows Languages ===
dism /online /get-intl
echo.
pause
goto MENU

:VERSION
cls
echo === Windows Version ===
ver
systeminfo | findstr /B /C:"OS Name" /C:"OS Version" /C:"System Type"
echo.
pause
goto MENU

:RECOVERY
cls
echo === Windows Recovery Environment ===
reagentc /info
echo.
pause
goto MENU

if "%choice%"=="4" goto DIAG
:DIAG
cls
echo === System Diagnostics ===
echo Computer: %COMPUTERNAME%
echo User: %USERNAME%
echo Architecture: %PROCESSOR_ARCHITECTURE%
echo.
pause
goto MENU

:EXIT
endlocal
exit /b
