# Changelog

## V12
- Improved menu and diagnostics.

## V13
- Added system diagnostics.

## V14
- Added Windows Recovery Settings shortcut.

## V15
- Added menu refresh and improved diagnostics.

## V2.0
- Major menu redesign.
- Added system information.
- Added Recovery Environment status.
- Added installed-language information.
- Added Recovery Settings shortcut.
