# Windows 11 Recovery Manager — Source Archive

Versions included:
- V12
- V13
- V14
- V15
- V2.0

## Build/run
Run `windows-11.cmd` from the corresponding version folder on Windows 11.

These scripts are diagnostic/management examples. They do not automatically delete recovery partitions.
