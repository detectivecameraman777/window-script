﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Windows 11 Recovery Manager 2.0

:MENU
cls
echo ==========================================
echo Windows 11 Recovery Manager 2.0
echo ==========================================
echo.
echo 1. System information
echo 2. Recovery Environment status
echo 3. Installed Windows languages
echo 4. Recovery Settings
echo 5. System diagnostics
echo 0. Exit
echo.
set "choice="
set /p "choice=Select option: "

if "%choice%"=="1" goto SYSTEM
if "%choice%"=="2" goto RECOVERY
if "%choice%"=="3" goto LANG
if "%choice%"=="4" start ms-settings:recovery&goto MENU
if "%choice%"=="5" goto DIAG
if "%choice%"=="0" goto EXIT

echo Invalid selection.
timeout /t 2 /nobreak >nul
goto MENU

:SYSTEM
cls
echo === System Information ===
ver
systeminfo | findstr /B /C:"OS Name" /C:"OS Version" /C:"System Type"
echo.
pause
goto MENU

:RECOVERY
cls
echo === Recovery Environment ===
reagentc /info
echo.
pause
goto MENU

:LANG
cls
echo === Installed Languages ===
dism /online /get-intl
echo.
pause
goto MENU

:DIAG
cls
echo === System Diagnostics ===
echo Computer: %COMPUTERNAME%
echo User: %USERNAME%
echo Architecture: %PROCESSOR_ARCHITECTURE%
echo.
pause
goto MENU

:EXIT
endlocal
exit /b
